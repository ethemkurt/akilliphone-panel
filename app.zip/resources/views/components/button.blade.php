<button type="{{ $type }}" class="btn btn-{{ $buttonType }}" name="{{ $name }}" value="{{ $value }}">{!! $label !!}</button>
