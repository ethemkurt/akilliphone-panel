<label class="form-label" for="{{ $name }}">{{ $label }}</label>
<input
  type="text"
  id="{{ $name }}"
  name="{{ $name }}"
  class="form-control"
  placeholder="{{ $placeholder }}"
/>
