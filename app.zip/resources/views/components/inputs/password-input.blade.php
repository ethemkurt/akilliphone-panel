<label class="form-label" for="{{ $name }}">{{ $label }}</label>
    <input
      type="password"
      id="{{ $name }}"
      name="{{ $name }}"
      class="form-control"
      placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
    />
