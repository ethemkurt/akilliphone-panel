<label class="form-label" for="{{ $name }}">{{ $label }}</label>
<input
  type="text"
  class="form-control"
  id="{{ $name }}"
  name="{{ $name }}"
  placeholder="{{ $placeholder }}"
/>
